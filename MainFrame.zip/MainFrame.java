
import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class MainFrame {

    // Week 8: File used to store freeze information
    private static final String FREEZE_FILE = "freezeData.data";

    // Week 8: Save freeze information to file
    private static void saveFreezeData(LocalDateTime freezeDateTime) {

        try (BufferedWriter writer =
                     new BufferedWriter(
                             new FileWriter(FREEZE_FILE))) {

            writer.write(
                    freezeDateTime.format(
                            DateTimeFormatter.ISO_LOCAL_DATE_TIME
                    )
            );

        } catch (IOException ex) {

            JOptionPane.showMessageDialog(
                    null,
                    "Unable to save freeze information.\n"
                            + ex.getMessage(),
                    "File Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }

    // Week 9: Read saved freeze information when the program starts
    private static LocalDateTime loadFreezeData() {

        try (BufferedReader reader =
                     new BufferedReader(
                             new FileReader(FREEZE_FILE))) {

            String savedFreezeData = reader.readLine();

            if (savedFreezeData != null
                    && !savedFreezeData.trim().isEmpty()) {

                return LocalDateTime.parse(
                        savedFreezeData.trim()
                );
            }

        } catch (IOException ex) {

            // No freeze file is normal on the first run.

        } catch (DateTimeParseException ex) {

            JOptionPane.showMessageDialog(
                    null,
                    "Saved freeze information is invalid.",
                    "File Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }

        return null;
    }

    public static void main(String[] args) {

        JFrame frame = new JFrame("Advanced Stopwatch");
        frame.setSize(700, 550);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel titleLabel = new JLabel("ADVANCED STOPWATCH");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 26));
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel timeLabel = new JLabel("00:00:00:000");
        timeLabel.setFont(new Font("Arial", Font.BOLD, 42));
        timeLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JPanel buttonPanel = new JPanel(new FlowLayout());

        JButton startButton = new JButton("Start");
        JButton pauseButton = new JButton("Pause");
        JButton resumeButton = new JButton("Resume");
        JButton resetButton = new JButton("Reset");

        buttonPanel.add(startButton);
        buttonPanel.add(pauseButton);
        buttonPanel.add(resumeButton);
        buttonPanel.add(resetButton);

        JLabel statusLabel = new JLabel("Status: Ready");
        statusLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        statusLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        long[] elapsedTime = {0};
        long[] lastStartTime = {0};

        Timer timer = new Timer(10, e -> {

            long currentTime = System.currentTimeMillis();

            long totalTime =
                    elapsedTime[0] +
                    (currentTime - lastStartTime[0]);

            long hours = totalTime / 3600000;
            long minutes = (totalTime % 3600000) / 60000;
            long seconds = (totalTime % 60000) / 1000;
            long milliseconds = totalTime % 1000;

            timeLabel.setText(
                    String.format(
                            "%02d:%02d:%02d:%03d",
                            hours,
                            minutes,
                            seconds,
                            milliseconds
                    )
            );
        });

        // START
        startButton.addActionListener(e -> {

            elapsedTime[0] = 0;

            lastStartTime[0] =
                    System.currentTimeMillis();

            timer.start();

            startButton.setEnabled(false);
            pauseButton.setEnabled(true);
            resumeButton.setEnabled(false);
            resetButton.setEnabled(true);

            statusLabel.setText("Status: Running");
        });

        // PAUSE
        pauseButton.addActionListener(e -> {

            if (timer.isRunning()) {

                long currentTime =
                        System.currentTimeMillis();

                elapsedTime[0] +=
                        currentTime - lastStartTime[0];

                timer.stop();

                startButton.setEnabled(false);
                pauseButton.setEnabled(false);
                resumeButton.setEnabled(true);
                resetButton.setEnabled(true);

                statusLabel.setText("Status: Paused");
            }
        });

        // RESUME
        resumeButton.addActionListener(e -> {

            lastStartTime[0] =
                    System.currentTimeMillis();

            timer.start();

            startButton.setEnabled(false);
            pauseButton.setEnabled(true);
            resumeButton.setEnabled(false);
            resetButton.setEnabled(true);

            statusLabel.setText("Status: Running");
        });

        // RESET
        resetButton.addActionListener(e -> {

            timer.stop();

            elapsedTime[0] = 0;
            lastStartTime[0] = 0;

            timeLabel.setText("00:00:00:000");

            startButton.setEnabled(true);
            pauseButton.setEnabled(false);
            resumeButton.setEnabled(false);
            resetButton.setEnabled(false);

            statusLabel.setText("Status: Ready");
        });

        // Date Calculator Panel
        JPanel datePanel =
                new JPanel(new FlowLayout(FlowLayout.LEFT));

        datePanel.setBorder(
                BorderFactory.createTitledBorder(
                        "Date Difference Calculator"
                )
        );

        JLabel dateLabel =
                new JLabel("Enter Date (dd-mm-yyyy):");

        JTextField dateField =
                new JTextField(15);

        JButton calculateButton =
                new JButton("Calculate");

        datePanel.add(dateLabel);
        datePanel.add(dateField);
        datePanel.add(calculateButton);

        // Week 6 Date Difference Calculator
        calculateButton.addActionListener(e -> {

            try {

                DateTimeFormatter formatter =
                        DateTimeFormatter.ofPattern("dd-MM-yyyy");

                LocalDate enteredDate =
                        LocalDate.parse(dateField.getText(), formatter);

                LocalDate currentDate =
                        LocalDate.now();

                if (enteredDate.isAfter(currentDate)) {

                    JOptionPane.showMessageDialog(
                            frame,
                            "Please enter a date that is not in the future.",
                            "Invalid Date",
                            JOptionPane.ERROR_MESSAGE
                    );

                    return;
                }

                Period period =
                        Period.between(enteredDate, currentDate);

                JOptionPane.showMessageDialog(
                        frame,
                        "Difference: "
                                + period.getYears() + " years "
                                + period.getMonths() + " months "
                                + period.getDays() + " days",
                        "Date Difference",
                        JOptionPane.INFORMATION_MESSAGE
                );

            } catch (DateTimeParseException ex) {

                JOptionPane.showMessageDialog(
                        frame,
                        "Invalid date format.\nPlease enter the date as dd-mm-yyyy.",
                        "Invalid Date",
                        JOptionPane.ERROR_MESSAGE
                );
            }
        });

        // Freeze Panel
        JPanel freezePanel =
                new JPanel(new FlowLayout(FlowLayout.LEFT));

        freezePanel.setBorder(
                BorderFactory.createTitledBorder(
                        "Freeze Stopwatch"
                )
        );

        JLabel freezeDateLabel =
                new JLabel("Date:");

        JTextField freezeDateField =
                new JTextField(10);

        JLabel freezeTimeLabel =
                new JLabel("Time:");

        JTextField freezeTimeField =
                new JTextField(8);

        JButton freezeButton =
                new JButton("Freeze");

        freezePanel.add(freezeDateLabel);
        freezePanel.add(freezeDateField);
        freezePanel.add(freezeTimeLabel);
        freezePanel.add(freezeTimeField);
        freezePanel.add(freezeButton);

        // Week 7 Freeze Time
        final LocalDateTime[] freezeDateTime = {null};

        Timer freezeTimer = new Timer(1000, e -> {

            if (freezeDateTime[0] != null) {

                LocalDateTime currentDateTime =
                        LocalDateTime.now();

                if (!currentDateTime.isBefore(freezeDateTime[0])) {

                    if (timer.isRunning()) {

                        long currentTime =
                                System.currentTimeMillis();

                        elapsedTime[0] +=
                                currentTime - lastStartTime[0];

                        timer.stop();
                    }

                    freezeDateTime[0] = null;

                    startButton.setEnabled(false);
                    pauseButton.setEnabled(false);
                    resumeButton.setEnabled(true);
                    resetButton.setEnabled(true);

                    statusLabel.setText("Status: Frozen");

                    JOptionPane.showMessageDialog(
                            frame,
                            "The stopwatch has been frozen.",
                            "Freeze Time",
                            JOptionPane.INFORMATION_MESSAGE
                    );
                }
            }
        });

        freezeButton.addActionListener(e -> {

            try {

                DateTimeFormatter dateFormatter =
                        DateTimeFormatter.ofPattern("dd-MM-yyyy");

                DateTimeFormatter timeFormatter =
                        DateTimeFormatter.ofPattern("HH:mm:ss");

                LocalDate freezeDate =
                        LocalDate.parse(
                                freezeDateField.getText(),
                                dateFormatter
                        );

                LocalTime freezeTime =
                        LocalTime.parse(
                                freezeTimeField.getText(),
                                timeFormatter
                        );

                LocalDateTime selectedDateTime =
                        LocalDateTime.of(
                                freezeDate,
                                freezeTime
                        );

                if (!selectedDateTime.isAfter(
                        LocalDateTime.now())) {

                    JOptionPane.showMessageDialog(
                            frame,
                            "Please enter a future date and time.",
                            "Invalid Freeze Time",
                            JOptionPane.ERROR_MESSAGE
                    );

                    return;
                }

                freezeDateTime[0] =
                        selectedDateTime;

                // Week 8: Store freeze information in freezeData.data
                saveFreezeData(selectedDateTime);

                freezeTimer.start();

                statusLabel.setText(
                        "Status: Freeze Scheduled"
                );

                JOptionPane.showMessageDialog(
                        frame,
                        "Freeze scheduled for:\n"
                                + freezeDateField.getText()
                                + " "
                                + freezeTimeField.getText(),
                        "Freeze Time",
                        JOptionPane.INFORMATION_MESSAGE
                );

            } catch (DateTimeParseException ex) {

                JOptionPane.showMessageDialog(
                        frame,
                        "Invalid date or time.\n\n"
                                + "Date format: dd-mm-yyyy\n"
                                + "Time format: HH:mm:ss",
                        "Invalid Freeze Time",
                        JOptionPane.ERROR_MESSAGE
                );
            }
        });

        mainPanel.add(titleLabel);
        mainPanel.add(Box.createVerticalStrut(20));

        mainPanel.add(timeLabel);
        mainPanel.add(Box.createVerticalStrut(15));

        mainPanel.add(buttonPanel);
        mainPanel.add(Box.createVerticalStrut(25));

        mainPanel.add(datePanel);
        mainPanel.add(Box.createVerticalStrut(20));

        mainPanel.add(freezePanel);
        mainPanel.add(Box.createVerticalStrut(20));

        mainPanel.add(statusLabel);

        frame.add(mainPanel);

        frame.setVisible(true);

        // Week 9: Load previously saved freeze information on startup
        LocalDateTime savedFreezeDateTime =
                loadFreezeData();

        if (savedFreezeDateTime != null) {

            freezeDateTime[0] =
                    savedFreezeDateTime;

            if (LocalDateTime.now().isBefore(
                    savedFreezeDateTime)) {

                freezeTimer.start();

                statusLabel.setText(
                        "Status: Freeze Scheduled"
                );

            } else {

                if (timer.isRunning()) {

                    long currentTime =
                            System.currentTimeMillis();

                    elapsedTime[0] +=
                            currentTime - lastStartTime[0];

                    timer.stop();
                }

                freezeDateTime[0] = null;

                startButton.setEnabled(false);
                pauseButton.setEnabled(false);
                resumeButton.setEnabled(true);
                resetButton.setEnabled(true);

                statusLabel.setText(
                        "Status: Frozen"
                );
            }
        }
    }
}

