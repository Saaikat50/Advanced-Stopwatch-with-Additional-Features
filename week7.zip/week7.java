import javax.swing.*;
import java.awt.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class week7 {

    public static void main(String[] args) {

        JFrame frame = new JFrame("Advanced Stopwatch");
        frame.setSize(700, 550);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel titleLabel = new JLabel("ADVANCED STOPWATCH");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 26));
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel timeLabel = new JLabel("00:00:00:000");
        timeLabel.setFont(new Font("Arial", Font.BOLD, 42));
        timeLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JPanel buttonPanel = new JPanel(new FlowLayout());

        JButton startButton = new JButton("Start");
        JButton pauseButton = new JButton("Pause");
        JButton resumeButton = new JButton("Resume");
        JButton resetButton = new JButton("Reset");

        buttonPanel.add(startButton);
        buttonPanel.add(pauseButton);
        buttonPanel.add(resumeButton);
        buttonPanel.add(resetButton);

        JLabel statusLabel = new JLabel("Status: Ready");
        statusLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        statusLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        // =========================
        // STOPWATCH VARIABLES
        // =========================

        long[] elapsedTime = {0};
        long[] lastStartTime = {0};

        // =========================
        // STOPWATCH TIMER
        // =========================

        Timer timer = new Timer(10, e -> {

            long currentTime = System.currentTimeMillis();

            long totalTime =
                    elapsedTime[0]
                    + (currentTime - lastStartTime[0]);

            long hours = totalTime / 3600000;
            long minutes = (totalTime % 3600000) / 60000;
            long seconds = (totalTime % 60000) / 1000;
            long milliseconds = totalTime % 1000;

            timeLabel.setText(
                    String.format(
                            "%02d:%02d:%02d:%03d",
                            hours,
                            minutes,
                            seconds,
                            milliseconds
                    )
            );
        });

        // START
        startButton.addActionListener(e -> {

            elapsedTime[0] = 0;
            lastStartTime[0] =
                    System.currentTimeMillis();

            timer.start();

            startButton.setEnabled(false);
            pauseButton.setEnabled(true);
            resumeButton.setEnabled(false);
            resetButton.setEnabled(true);

            statusLabel.setText("Status: Running");
        });

        // PAUSE
        pauseButton.addActionListener(e -> {

            if (timer.isRunning()) {

                long currentTime =
                        System.currentTimeMillis();

                elapsedTime[0] +=
                        currentTime - lastStartTime[0];

                timer.stop();

                startButton.setEnabled(false);
                pauseButton.setEnabled(false);
                resumeButton.setEnabled(true);
                resetButton.setEnabled(true);

                statusLabel.setText("Status: Paused");
            }
        });

        // RESUME
        resumeButton.addActionListener(e -> {

            lastStartTime[0] =
                    System.currentTimeMillis();

            timer.start();

            startButton.setEnabled(false);
            pauseButton.setEnabled(true);
            resumeButton.setEnabled(false);
            resetButton.setEnabled(true);

            statusLabel.setText("Status: Running");
        });

        // RESET
        resetButton.addActionListener(e -> {

            timer.stop();

            elapsedTime[0] = 0;
            lastStartTime[0] = 0;

            timeLabel.setText("00:00:00:000");

            startButton.setEnabled(true);
            pauseButton.setEnabled(false);
            resumeButton.setEnabled(false);
            resetButton.setEnabled(false);

            statusLabel.setText("Status: Ready");
        });

        // =========================
        // DATE CALCULATOR
        // =========================

        JPanel datePanel =
                new JPanel(new FlowLayout());

        JLabel fromLabel =
                new JLabel("From:");

        JTextField fromDateField =
                new JTextField(10);

        JLabel toLabel =
                new JLabel("To:");

        JTextField toDateField =
                new JTextField(10);

        JButton calculateButton =
                new JButton("Calculate");

        datePanel.add(fromLabel);
        datePanel.add(fromDateField);
        datePanel.add(toLabel);
        datePanel.add(toDateField);
        datePanel.add(calculateButton);

        JLabel dateResultLabel =
                new JLabel("Difference: ");

        dateResultLabel.setAlignmentX(
                Component.CENTER_ALIGNMENT
        );

        DateTimeFormatter formatter =
                DateTimeFormatter.ofPattern("dd-MM-yyyy");

        // DATE CALCULATOR
        calculateButton.addActionListener(e -> {

            try {

                LocalDate startDate =
                        LocalDate.parse(
                                fromDateField.getText(),
                                formatter
                        );

                LocalDate endDate =
                        LocalDate.parse(
                                toDateField.getText(),
                                formatter
                        );

                LocalDate today =
                        LocalDate.now();

                if (startDate.isAfter(today)
                        || endDate.isAfter(today)) {

                    JOptionPane.showMessageDialog(
                            frame,
                            "Future dates are not allowed.",
                            "Invalid Date",
                            JOptionPane.ERROR_MESSAGE
                    );

                    return;
                }

                if (endDate.isBefore(startDate)) {

                    JOptionPane.showMessageDialog(
                            frame,
                            "The To date must be after the From date.",
                            "Invalid Date",
                            JOptionPane.ERROR_MESSAGE
                    );

                    return;
                }

                Period period =
                        Period.between(
                                startDate,
                                endDate
                        );

                dateResultLabel.setText(
                        "Difference: "
                        + period.getYears()
                        + " years, "
                        + period.getMonths()
                        + " months, "
                        + period.getDays()
                        + " days"
                );

            } catch (DateTimeParseException ex) {

                JOptionPane.showMessageDialog(
                        frame,
                        "Please enter dates in dd-MM-yyyy format.",
                        "Invalid Date",
                        JOptionPane.ERROR_MESSAGE
                );
            }
        });

        // =========================
        // FREEZE TIME FEATURE
        // =========================

        JPanel freezePanel =
                new JPanel(new FlowLayout());

        JLabel freezeLabel =
                new JLabel("Freeze Time:");

        JTextField freezeDateField =
                new JTextField(10);

        JTextField freezeTimeField =
                new JTextField(8);

        JButton freezeButton =
                new JButton("Freeze");

        freezePanel.add(freezeLabel);
        freezePanel.add(freezeDateField);
        freezePanel.add(freezeTimeField);
        freezePanel.add(freezeButton);

        // Store freeze time
        LocalDateTime[] freezeDateTime =
                {null};

        // Timer for checking freeze time
        Timer[] freezeTimer = new Timer[1];

        freezeTimer[0] =
                new Timer(1000, e -> {

                    if (freezeDateTime[0] != null) {

                        LocalDateTime now =
                                LocalDateTime.now();

                        if (!now.isBefore(
                                freezeDateTime[0])) {

                            timer.stop();

                            statusLabel.setText(
                                    "Status: Frozen"
                            );

                            freezeTimer[0].stop();

                            JOptionPane.showMessageDialog(
                                    frame,
                                    "Time has been frozen."
                            );
                        }
                    }
                });

        // FREEZE BUTTON
        freezeButton.addActionListener(e -> {

            try {

                LocalDate freezeDate =
                        LocalDate.parse(
                                freezeDateField.getText(),
                                formatter
                        );

                LocalTime freezeTime =
                        LocalTime.parse(
                                freezeTimeField.getText()
                        );

                LocalDateTime selectedDateTime =
                        LocalDateTime.of(
                                freezeDate,
                                freezeTime
                        );

                LocalDateTime now =
                        LocalDateTime.now();

                if (!selectedDateTime.isAfter(now)) {

                    JOptionPane.showMessageDialog(
                            frame,
                            "Freeze time must be in the future.",
                            "Invalid Freeze Time",
                            JOptionPane.ERROR_MESSAGE
                    );

                    return;
                }

                freezeDateTime[0] =
                        selectedDateTime;

                freezeTimer[0].start();

                statusLabel.setText(
                        "Status: Freeze Scheduled"
                );

            } catch (DateTimeParseException ex) {

                JOptionPane.showMessageDialog(
                        frame,
                        "Please enter a valid date and time.",
                        "Invalid Freeze Time",
                        JOptionPane.ERROR_MESSAGE
                );
            }
        });

        // =========================
        // ADD COMPONENTS
        // =========================

        mainPanel.add(titleLabel);
        mainPanel.add(
                Box.createVerticalStrut(20)
        );

        mainPanel.add(timeLabel);
        mainPanel.add(
                Box.createVerticalStrut(15)
        );

        mainPanel.add(buttonPanel);
        mainPanel.add(
                Box.createVerticalStrut(20)
        );

        mainPanel.add(statusLabel);
        mainPanel.add(
                Box.createVerticalStrut(25)
        );

        mainPanel.add(datePanel);
        mainPanel.add(
                Box.createVerticalStrut(15)
        );

        mainPanel.add(dateResultLabel);
        mainPanel.add(
                Box.createVerticalStrut(20)
        );

        mainPanel.add(freezePanel);

        frame.add(mainPanel);
        frame.setVisible(true);
    }
}